from dataclasses import dataclass, field, InitVar
from typing import ClassVar, Dict, List, Optional, Set
import firebase_admin
from firebase_admin import auth, credentials, firestore
import numpy as np
import random
import string

SEED = 0
EVENTS = ["ceremony", "cocktail_parade", "harbour_cruise", "wedding_breakfast", "evening"]
MAX_PINS = 100
KEY_PATH = "/Users/lukehg/Downloads/lukeandkaywedding-firebase-adminsdk-fbsvc-cd255a708b.json"
cred = credentials.Certificate(KEY_PATH)
firebase_admin.initialize_app(cred)
db = firestore.client()
np.random.seed(SEED)
random.seed(SEED)

guests_ref = db.collection("guests")

MENU_FIELDS = {
    "starter_terrine": False,
    "starter_salmon": False,
    "starter_celeriac": False,
    "main_ox_cheek": False,
    "main_fish_of_the_day": False,
    "main_gnocchi": False,
    "dessert_chocolate_mousse": False,
    "dessert_lemon_posset": False,
    "dessert_rice_pudding": False,
}

batch = db.batch()

for guest_doc in guests_ref.stream():
    guest_ref = guest_doc.reference
    batch.update(guest_ref, MENU_FIELDS)

batch.commit()