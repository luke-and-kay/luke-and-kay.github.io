from dataclasses import dataclass, field
from typing import Dict, List, Optional
import firebase_admin
from firebase_admin import credentials, firestore

KEY_PATH = "/Users/lukehg/Downloads/lukeandkaywedding-firebase-adminsdk-fbsvc-cd255a708b.json"

EVENTS = ["ceremony", "cocktail_parade", "harbour_cruise", "wedding_breakfast", "evening"]

@dataclass
class Guest:
    id: str
    display_id: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone_number: Optional[str] = None
    earliest_event: str = "ceremony"
    vegetarian: Optional[bool] = None
    vegan: Optional[bool] = None
    kids_menu: Optional[bool] = None
    dietary_requirements: Optional[str] = None
    attendance: Optional[Dict] = field(default_factory=dict)

    question_1_answer: Optional[str] = None
    question_2_answer: Optional[str] = None
    question_3_answer: Optional[str] = None
    question_4_answer: Optional[str] = None
    question_5_answer: Optional[str] = None

    def __post_init__(self):
        event_id = EVENTS.index(self.earliest_event)
        valid_events = EVENTS[event_id:]
        self.attendance = {k: True for k in valid_events}
        

cred = credentials.Certificate(KEY_PATH)
firebase_admin.initialize_app(cred)

db = firestore.client()


def create_guest(guest: Guest):

    guest_dict = guest.__dict__
    guest_id = guest_dict.pop("id")

    db.collection("guests").document(guest_id).set(guest_dict)
    print(f"Created/updated guest '{guest_id}' with data: {guest_dict}")


def main():

    guests = [
        Guest("luke_hudlass_galley", "Luke", "Luke", "Hudlass-Galley"),
        Guest("kayleigh_auton", "Kayleigh", "Kayleigh", "Auton"),
        Guest("abi_hudlass_galley", "Abigail", "Abigail", "Hudlass-Galley"),
        Guest("chris_galley", "Christopher", "Christopher", "Galley"),
        Guest("jake_hudlass", "Jake", "Jake", "Hudlass"),
        Guest("beth_hudlass", "Beth" "Beth", "Hudlass"),
        Guest("arthur_hudlass", "Arthur", "Arthur", "Hudlass", kids_menu=True),
        Guest("darcie_hudlass", "Darcie", "Darcie", "Hudlass", kids_menu=True),
        Guest("wendy_hudlass", "Wendy", "Wendy", "Hudlass"),
        Guest("pat_hudlass", "Pat", "Patrick"),
        Guest("ollie_auton", "Ollie", "Ollie", "Auton"),
        Guest("vicky_auton", "Vicky", "Vicky", "Auton"),
        Guest("harry_auton", "Harry", "Harry", "Auton", kids_menu=True),
        Guest("alison_brandon", "Alison", "Alison", "Brandon"),
        Guest("steph_stevens", "Stephanie", "Stephanie", "Stevens"),
        Guest("calum_stevens", "Calum", "Calum", "Stevens"),
        Guest("harry_brandon", "Harry", "Harry", "Brandon"),
        Guest("darcey_goble", "Darcey", "Darcey", "Goble"),
        Guest("simon_green", "Simon", "Simon", "Green"),
        Guest("kim_green", "Kim", "Kim", "Green"),
        
    ]

    for guest in guests:
        create_guest(guest)




if __name__ == "__main__":
    main()
