from dataclasses import dataclass, field, InitVar
from typing import ClassVar, Dict, List, Optional, Set
import firebase_admin
from firebase_admin import auth, credentials, firestore
import numpy as np
import random
import string

SEED = 0
EVENTS = ["ceremony", "cocktail_parade", "harbour_cruise", "wedding_breakfast", "evening"]
MAX_PINS = 100
KEY_PATH = "/Users/lukehg/Downloads/lukeandkaywedding-firebase-adminsdk-fbsvc-cd255a708b.json"
cred = credentials.Certificate(KEY_PATH)
firebase_admin.initialize_app(cred)
db = firestore.client()
np.random.seed(SEED)
random.seed(SEED)

guests_ref = db.collection("guests")

query = guests_ref.where("submitted_form", "==", True).stream()

print("")
submitted_guests = []
for i, doc in enumerate(query):
    data = doc.to_dict()
    submitted_guests.append(data)
    print(f"{i + 1}: {doc.id}: {data['first_name']} {data['last_name']}, {data['favourite_dessert']}")
print("")