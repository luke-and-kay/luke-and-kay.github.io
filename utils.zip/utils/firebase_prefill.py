from dataclasses import dataclass, field, InitVar
from typing import ClassVar, Dict, List, Optional, Set
import firebase_admin
from firebase_admin import auth, credentials, firestore
import numpy as np
import random
import string

SEED = 0
EVENTS = ["ceremony", "cocktail_parade", "harbour_cruise", "wedding_breakfast", "evening"]
MAX_PINS = 100
KEY_PATH = "/Users/lukehg/Downloads/lukeandkaywedding-firebase-adminsdk-fbsvc-cd255a708b.json"
cred = credentials.Certificate(KEY_PATH)
firebase_admin.initialize_app(cred)
db = firestore.client()
np.random.seed(SEED)
random.seed(SEED)



@dataclass
class Guest:
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone_number: Optional[str] = None
    earliest_event: str = "ceremony"
    submitted_form: bool = False
    child: bool = False
    plus_one: bool = False
    vegetarian: bool = False
    vegan: bool = False
    dietary_requirements: Optional[str] = None
    attendance: Optional[Dict] = field(default_factory=dict)

    go_to_karaoke_song: Optional[str] = None
    favourite_movie: Optional[str] = None
    favorite_holiday_destination: Optional[str] = None
    name_of_pet: Optional[str] = None
    favourite_dessert: Optional[str] = None

    # question_1_answer: Optional[str] = None
    # question_2_answer: Optional[str] = None
    # question_3_answer: Optional[str] = None
    # question_4_answer: Optional[str] = None
    # question_5_answer: Optional[str] = None
    _used_ids: ClassVar[Set[str]] = set()

    def __post_init__(self):
        event_id = EVENTS.index(self.earliest_event)
        valid_events = EVENTS[event_id:]
        self.attendance = {k: True for k in valid_events}

        
@dataclass
class Party:
    party_name: str
    guests: List[Guest]
    pin: Optional[str] = field(default_factory=str)
    create_new_account: bool = True
    guest_id_start: Optional[int] = 1
    _used_pins: ClassVar[Set[str]] = set()

    def __post_init__(self):
        if not self.pin:
            while True:
                candidate = ''.join(random.choices(string.digits, k=6))
                if candidate not in self._used_pins:
                    self._used_pins.add(candidate)
                    self.pin = candidate
                    break
        # try:
        print(self.party_name, self.pin)
        if True:
            if self.create_new_account:
                auth.create_user(
                    email=f"{self.pin}@lukeandkay.co.uk",
                    email_verified=False,
                    password=self.pin,
                    display_name=self.pin,
                    disabled=False,
                )
            guest_references = []
            for counter, guest in enumerate(self.guests):
                guest_dict = guest.__dict__
                guest_id = f"{self.pin}:guest_{counter + self.guest_id_start}"
                guest_ref = db.collection("guests").document(guest_id)
                guest_ref.set(guest_dict)
                guest_references += [guest_ref]
            db.collection("users").document(self.pin).set({
                "party_name": self.party_name,
                "guests": guest_references,
            })
            print(self.party_name, self.pin)
        # except:
        #     pass

def delete_collection(coll_ref, batch_size: int = 500):
    docs = coll_ref.limit(batch_size).stream()
    deleted = 0
    for doc in docs:
        print(f"Deleting doc {doc.id} from {coll_ref.id}")
        doc.reference.delete()
        deleted += 1
    if deleted >= batch_size:
        return delete_collection(coll_ref, batch_size)

def clear_database(batch_size: int = 1000):
    while True:
        page = auth.list_users(max_results=batch_size)
        uids = [user.uid for user in page.users]
        if not uids:
            break
        auth.delete_users(uids)
        if not page.next_page_token:
            break
    collections = db.collections()
    for coll in collections:
        print(f"Processing collection: {coll.id}")
        delete_collection(coll)



if __name__ == "__main__":


    # clear_database()

    # Party("Test Guests", [
    #     Guest("Paul", "Rudd"),
    #     Guest("Elizabeth", "Olsen"),
    #     Guest("Owen", "Wilson", child=True),
    #     Guest("Later", "Guest", earliest_event="cocktail_parade")
    # ])

    # Party("Luke & Kayleigh", [
    #     Guest("Luke", "Hudlass-Galley"),
    #     Guest("Kayleigh", "Auton"),
    # ])

    # Party("Abi & Chris", [
    #     Guest("Abigail", "Hudlass-Galley"),
    #     Guest("Christopher", "Galley"),
    # ])

    # Party("Jake, Beth, Athur & Darcie", [
    #     Guest("Jake", "Hudlass"),
    #     Guest("Beth", "Hudlass"),
    #     Guest("Arthur", "Hudlass", child=True),
    #     Guest("Darcie", "Hudlass", child=True),
    # ])

    # Party("Nana", [
    #     Guest("Wendy", "Hudlass"),
    # ])

    # Party("Pat", [
    #     Guest("Patrick"),
    # ])

    # #10

    # Party("Ollie, Vicky & Harry", [
    #     Guest("Ollie", "Auton"),
    #     Guest("Vicky", "Auton"),
    #     Guest("Harry", "Auton", child=True),
    # ])

    # Party("Angela, Adrian and Laurence", [
    #     Guest("Angela", "Auton"),
    #     Guest("Adrian", "Auton"),
    #     Guest("Laurence", "Auton"),
    # ])

    # Party("Alison", [
    #     Guest("Alison", "Brandon"),
    # ])

    # Party("Steph & Calum", [
    #     Guest("Stephanie", "Stevens"),
    #     Guest("Calum", "Stevens"),
    # ])

    # Party("Harry & Darcey", [
    #     Guest("Harry", "Brandon"),
    #     Guest("Darcey", "Goble"),
    # ])

    # Party("Simon & Kim", [
    #     Guest("Simon", "Green"),
    #     Guest("Kim", "Green"),
    # ])

    # #23

    # Party("Dan", [
    #     Guest("Daniel Knowles"),
    # ])

    # Party("Abbey", [
    #     Guest("Abbey", "Lamb"),
    # ])

    # Party("Maddie & Jamie", [
    #     Guest("Maddie", "Elliott"),
    #     Guest("Jamie", "Parkinson", earliest_event="cocktail_parade"),
    # ],
    # pin="988953")

    # Party("Freddie", [
    #     Guest("Freddie", "Bettridge"),
    # ])

    # Party("Christian", [
    #     Guest("Christian", "Eastwood"),
    # ])

    # Party("Michael", [
    #     Guest("Michael", "Stephens"), # FIGURE THIS ONE OUT!!
    # ])

    # #29

    # Party("Alex & Cei", [
    #     Guest("Alex", "Church"),
    #     Guest("Ceirios", "Leach"),
    # ])

    # Party("Kenny", [
    #     Guest("Ethan", "Kenwrick"),
    # ])

    # #32

    # Party("Helen & Will", [
    #     Guest("Helen", "Byrne"),
    #     Guest("Will"),
    # ])

    # Party("Arianna & Tom", [
    #     Guest("Arianna", "Saracino"),
    #     Guest("Tom", "Murray"),
    # ])

    # Party("Alex & Sophie", [
    #     Guest("Alex", "Titterton"),
    #     Guest("Sophie", )
    # ])

    # Party("Kerstin & Jorge", [
    #     Guest("Kerstin", "Kläser"),
    #     Guest("Jorge"),
    # ])

    # Party("Ivan & Karim", [
    #     Guest("Ivan", "Chelombiev"),
    #     Guest("Karim", "Badr"),
    # ])

    # Party("Luka & Sandy", [
    #     Guest("Luka", "Ribar"),
    #     Guest("Sandy", "Hadaya")
    # ])

    # Party("Dirty Berty", [
    #     Guest("Alberto", "Cattaneo"),
    # ])

    # Party("Luke & Hattie", [  
    #     Guest("Luke", "Prince"),
    #     Guest("Hattie"),
    # ])

    # # 47

    # Party("Jen", [  
    #     Guest("Jen", "Ashfield"),
    # ])

    # Party("Claire & Sam", [  
    #     Guest("Claire", "Hayward"),
    #     Guest("Sam", "Hayward"),
    # ])

    # Party("David & Becci", [  
    #     Guest("David", "Aavramides"),
    #     Guest("Becci"),
    # ])

    # Party("Helen", [  
    #     Guest("Helen", "Page"),
    # ])

    # Party("Caroline", [  
    #     Guest("Caroline", "Partridge"),
    # ])

    # Party("Kirsten", [  
    #     Guest("Kirsten", "Edwards"),
    # ])

    # Party("Nick & Lisa", [  
    #     Guest("Nick", "Gardner"),
    #     Guest("Lisa", "Gardner"),
    # ])

    # Party("Leanne", [  
    #     Guest("Leanne", "Bunting"),
    # ])

    # Party("Jenny", [  
    #     Guest("Jenny"),
    #     Guest("Jenny's Plus One"),
    # ])

    # Party("Tracey", [  
    #     Guest("Tracey", "Parsons"),
    #     Guest("Tracey's Plus One"),
    # ])


    # Party("Al", [
    #     Guest("Al", "Alexander"),
    #     Guest("Al's Plus One"),
    # ])

    # Party("Mark & Sarah", [
    #     Guest("Mark", "Pupilli"),
    #     Guest("Sarah"),
    # ])

    # Party("Nicki", [Guest("Nicki", "Corp")], pin="709589")
    # Party("Hattie", [Guest("Hattie", "Moore")], pin="600176")
    # Party("Evie-Rose", [Guest("Evie-Rose", "Young")], pin="460954")
    # Party("Jodi", [Guest("Jodi", "Irwin")], pin="856147")
    Party("Jodi", [Guest("Jason")], pin="856147", create_new_account=False, guest_id_start=2)
    


    # Party("Al", [
    #     Guest("Al", "Alexander", earliest_event="cocktail_parade"),
    # ])

    # Party("Mark", [
    #     Guest("Mark", "Pupilli", earliest_event="cocktail_parade"),
    # ])

    # 49
    



